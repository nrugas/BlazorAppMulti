﻿Remove-IISSite -Name "LawyersWeb" -Confirm:$False

rm -r "c:\inetpub\law" -Force