﻿Remove-IISSite -Name "KregWeb" -Confirm:$False

rm -r "c:\inetpub\kreg" -Force